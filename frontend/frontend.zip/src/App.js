import './App.css';

function App() {
  return (
    <div className="App">
     Hello world...!!
     This is the course of Cloud computing and 
     Devops with AWS certification
    </div>
  );
}

export default App;
